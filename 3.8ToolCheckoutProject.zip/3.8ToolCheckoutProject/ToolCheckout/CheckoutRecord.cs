/****************************************
Name: Chelsea Martin
Date: 5/31/2026
Assignment: SDC320 Course Project Tool Checkout System
*/

namespace ToolCheckout
{
    public class CheckoutRecord : Identifiable
    {
        public Tool Tool { get; set; }
        public User User { get; set; }
        public DateTime CheckedOut { get; set; }
        public DateTime? CheckedIn { get; set; }

        public CheckoutRecord(int id, Tool tool, User user)
            : base(id)
        {
            Tool = tool;
            User = user;
            CheckedOut = DateTime.Now;
            CheckedIn = null;
        }

        public void CheckIn()
        {
            CheckedIn = DateTime.Now;
            Tool.IsCheckedOut = false;
        }

        public string GetInfo()
        {
            string status = CheckedIn.HasValue
                ? $"Returned at {CheckedIn}"
                : "Not Returned";

            return $"Record ID: {Id}\nTool: {Tool.Name}\nUser: {User.FullName}\nChecked Out: {CheckedOut}\nStatus: {status}";
        }

        public override string ToString()
        {
            return $"{Tool.Name} checked out by {User.FullName} on {CheckedOut}";
        }
    }
}