/********************
Name: Chelsea Martin
Date: 5/31/2026
Assignment: SDC320 Course Project Tool Checkout System
*/

namespace ToolCheckout
{
    public class User : Identifiable
    {
        public string FullName { get; private set; }

        public User(int id, string fullName)
            : base(id)
        {
            FullName = fullName;
        }

        public string GetInfo()
        {
            return $"User ID: {Id}\nName: {FullName}";
        }

        public override string ToString()
        {
            return $"{FullName} (ID: {Id})";
        }
    }
}