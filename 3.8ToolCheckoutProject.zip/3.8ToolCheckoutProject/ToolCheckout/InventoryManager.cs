using System.Collections.Generic;
using System.Linq;

namespace ToolCheckout
{
    public class InventoryManager
    {
        private List<Tool> tools = new List<Tool>();
        private List<User> users = new List<User>();
        private List<CheckoutRecord> records = new List<CheckoutRecord>();

        private int nextToolId = 1;
        private int nextUserId = 1;
        private int nextRecordId = 1;

        // -----------------------------
        // TOOL METHODS
        // -----------------------------
        public Tool AddTool(string name, string category)
        {
            var tool = new Tool(nextToolId++, name, category);
            tools.Add(tool);
            return tool;
        }

        public List<Tool> GetTools()
        {
            return tools;
        }

        public bool UpdateTool(int id, string newName, string newCategory)
        {
            var tool = tools.FirstOrDefault(t => t.Id == id);
            if (tool == null) return false;

            tool.Update(newName, newCategory);

            return true;
        }

        public bool DeleteTool(int id)
        {
            var tool = tools.FirstOrDefault(t => t.Id == id);
            if (tool == null) return false;

            tools.Remove(tool);
            return true;
        }

        // -----------------------------
        // USER METHODS
        // -----------------------------
        public User AddUser(string fullName)
        {
            var user = new User(nextUserId++, fullName);
            users.Add(user);
            return user;
        }

        public List<User> GetUsers()
        {
            return users;
        }

        public bool DeleteUser(int id)
        {
            var user = users.FirstOrDefault(u => u.Id == id);
            if (user == null) return false;

            users.Remove(user);
            return true;
        }

        //Checkout Methods
        public CheckoutRecord? CheckoutTool(int toolId, int userId)
        {
            var tool = tools.FirstOrDefault(t => t.Id == toolId);
            var user = users.FirstOrDefault(u => u.Id == userId);

            if(tool == null || user == null || tool.IsCheckedOut)
                return null;
            
            tool.IsCheckedOut = true;

            var record = new CheckoutRecord(nextRecordId++, tool, user);
            records.Add(record);

            return record;
        }

        //Checkin Methods
        public bool CheckInTool(int toolId)
        {
            var record = records
                .Where(r => r.Tool.Id == toolId && r.CheckedIn == null)
                .FirstOrDefault();

                if(record == null)
                    return false;

                record.CheckIn();
                return true;
        }
    }
}
