/*********************
Name: Chelsea Martin
Date: 5/31/2026
Assignment: SDC320 Course Project Tool Checkout System
*/

namespace ToolCheckout
{
    public class Tool : Asset
    {
        public string Category { get; set; }
        public bool IsCheckedOut { get; set; }

        public Tool(int id, string name, string category)
            : base(id, name)
        {
            Category = category;
            IsCheckedOut = false;
        }

        public void Update(string newName, string newCategory)
        {
            Name = newName;
            Category = newCategory;
        }

        public override string GetInfo()
        {
            string status = IsCheckedOut ? "Checked Out" : "Available";
            return $"Tool ID: {Id}\nName: {Name}\nCategory: {Category}\nStatus: {status}";
        }

        public override string ToString()
        {
            return $"{Name} ({Category}) - {(IsCheckedOut ? "Checked Out" : "Available")}";
        }
    }
}