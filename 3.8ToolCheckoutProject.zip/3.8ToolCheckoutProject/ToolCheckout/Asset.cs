/*********************************
Name:Chelsea Martin
Date: 5/31/2026
Assignement: SDC320 Course Project Tool Checkout System

*/
namespace ToolCheckout
{
    public abstract class Asset : Identifiable
    {
        public string Name{get; protected set;}

        public Asset(int id, string name)
            : base(id)
        {
            Name = name;
        }
        public abstract string GetInfo();
        public override string ToString()
        {
            return $"{Id}: {Name}";
        }
    }
}