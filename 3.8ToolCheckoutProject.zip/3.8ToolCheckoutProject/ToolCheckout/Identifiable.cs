/*********************************
Name:Chelsea Martin
Date: 5/31/2026
Assignement: SDC320 Course Project Tool Checkout System

*/

namespace ToolCheckout
{
    public abstract class Identifiable
    {
        public int Id{get;}

        protected Identifiable (int id)
        {
            Id = id;
        }
    }
}