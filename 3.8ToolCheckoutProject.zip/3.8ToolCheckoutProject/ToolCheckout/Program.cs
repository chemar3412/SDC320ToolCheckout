﻿/****************************************
Name: Chelsea Martin
Date: 5/31/2026
Assignment: SDC320 Course Project Tool Checkout System
*/

using System;
using ToolCheckout;

public class Program
{
    public static void Main()
    {
        InventoryManager manager = new InventoryManager();

        Console.WriteLine("Chelsea - Week 3 Tool Checkout System");

        // Add tools
        var hammer = manager.AddTool("Hammer", "Hand Tool");
        var drill = manager.AddTool("Drill", "Power Tool");

        // Add users
        var user1 = manager.AddUser("John Smith");
        var user2 = manager.AddUser("Sarah Johnson");

        // Checkout tools
        var record1 = manager.CheckoutTool(hammer.Id, user1.Id);
        var record2 = manager.CheckoutTool(drill.Id, user2.Id);

        // Print info
        Console.WriteLine(record1?.GetInfo() ?? "Checkout failed.");
        Console.WriteLine();
        Console.WriteLine(record2?.GetInfo() ?? "Checkout failed.");

        // Check in a tool
        manager.CheckInTool(hammer.Id);

        Console.WriteLine("\nAfter Check-In:");
        Console.WriteLine(record1?.GetInfo() ?? "Checkout failed.");
    }
}