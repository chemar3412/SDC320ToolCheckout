using System;
using System.Data.Common;
using Microsoft.Data.Sqlite;

namespace ToolCheckout
{
    public static class SQLiteDatabase
    {
        public static DbConnection Connect(string databaseFilePath)
        {
            var cs = $"Data Source={databaseFilePath};";

            var conn = new SqliteConnection(cs);
            try
            {
                conn.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine("SQLite open error: " + e.Message);
                throw;
            }

            return conn;
        }
    }
}
