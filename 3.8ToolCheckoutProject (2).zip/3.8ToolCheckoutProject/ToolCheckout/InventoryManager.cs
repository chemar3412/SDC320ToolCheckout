using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace ToolCheckout
{
    using ToolCheckout.Repositories;

    public class InventoryManager
    {
        private List<Tool> tools = new List<Tool>();
        private List<User> users = new List<User>();
        private List<CheckoutRecord> records = new List<CheckoutRecord>();

        private int nextToolId = 1;
        private int nextUserId = 1;
        private int nextRecordId = 1;

        private readonly string databaseFilePath;
        private readonly ToolRepository toolRepo;
        private readonly UserRepository userRepo;
        private readonly CheckoutRepository checkoutRepo;

        public InventoryManager(string databaseFilePath = "toolcheckout.db")
        {
            this.databaseFilePath = databaseFilePath;
            DatabaseManagement.InitializeDatabase(databaseFilePath);

            toolRepo = new ToolRepository(databaseFilePath);
            userRepo = new UserRepository(databaseFilePath);
            checkoutRepo = new CheckoutRepository(databaseFilePath);

            LoadAllFromDatabase();
        }

        private void LoadAllFromDatabase()
        {
            tools = toolRepo.GetAll();
            users = userRepo.GetAll();
            records = checkoutRepo.GetAll(tools, users);

            // set next ids
            nextToolId = tools.Any() ? tools.Max(t => t.Id) + 1 : 1;
            nextUserId = users.Any() ? users.Max(u => u.Id) + 1 : 1;
            nextRecordId = records.Any() ? records.Max(r => r.Id) + 1 : 1;
        }

        // -----------------------------
        // TOOL METHODS (persisted)
        // -----------------------------
        public Tool AddTool(string name, string category)
        {
            var tool = new Tool(nextToolId++, name, category);

            toolRepo.Add(tool);
            tools.Add(tool);
            return tool;
        }

        public List<Tool> GetTools()
        {
            return tools;
        }

        public bool UpdateTool(int id, string newName, string newCategory)
        {
            var tool = tools.FirstOrDefault(t => t.Id == id);
            if (tool == null) return false;

            tool.Update(newName, newCategory);
            toolRepo.Update(tool);
            return true;
        }

        public bool DeleteTool(int id)
        {
            var tool = tools.FirstOrDefault(t => t.Id == id);
            if (tool == null) return false;

            // remove related checkout records first
            checkoutRepo.DeleteByTool(id);
            toolRepo.Delete(id);
            tools.Remove(tool);
            return true;
        }

        // -----------------------------
        // USER METHODS (persisted)
        // -----------------------------
        public User AddUser(string fullName)
        {
            var user = new User(nextUserId++, fullName);

            userRepo.Add(user);
            users.Add(user);
            return user;
        }

        public List<User> GetUsers()
        {
            return users;
        }

        public bool DeleteUser(int id)
        {
            var user = users.FirstOrDefault(u => u.Id == id);
            if (user == null) return false;

            // remove related checkout records first
            checkoutRepo.DeleteByUser(id);
            userRepo.Delete(id);
            users.Remove(user);
            return true;
        }

        //Checkout Methods (persisted)
        public CheckoutRecord? CheckoutTool(int toolId, int userId)
        {
            var tool = tools.FirstOrDefault(t => t.Id == toolId);
            var user = users.FirstOrDefault(u => u.Id == userId);

            if (tool == null || user == null || tool.IsCheckedOut)
                return null;

            var record = new CheckoutRecord(nextRecordId++, tool, user);
            checkoutRepo.Add(record);
            tool.IsCheckedOut = true;
            toolRepo.SetCheckedOut(tool.Id, true);
            records.Add(record);
            return record;
        }

        //Checkin Methods (persisted)
        public bool CheckInTool(int toolId)
        {
            var record = records
                .Where(r => r.Tool.Id == toolId && r.CheckedIn == null)
                .FirstOrDefault();

            if (record == null)
                return false;

            record.CheckIn();
            checkoutRepo.UpdateCheckedIn(record.Id, record.CheckedIn);
            toolRepo.SetCheckedOut(toolId, false);
            record.Tool.IsCheckedOut = false;
            return true;
        }
    }
}
