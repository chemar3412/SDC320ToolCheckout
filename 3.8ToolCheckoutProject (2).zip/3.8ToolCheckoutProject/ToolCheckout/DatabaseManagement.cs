using System;
using System.Data.Common;

namespace ToolCheckout
{
    public static class DatabaseManagement
    {
        public static void InitializeDatabase(string databaseFilePath)
        {
            using DbConnection conn = SQLiteDatabase.Connect(databaseFilePath);
            using DbCommand cmd = conn.CreateCommand();

            // Enable foreign keys
            cmd.CommandText = "PRAGMA foreign_keys = ON;";
            cmd.ExecuteNonQuery();

            // Users table
            cmd.CommandText =
                "CREATE TABLE IF NOT EXISTS Users (" +
                "Id INTEGER PRIMARY KEY, " +
                "FullName TEXT NOT NULL" +
                ");";
            cmd.ExecuteNonQuery();

            // Tools table
            cmd.CommandText =
                "CREATE TABLE IF NOT EXISTS Tools (" +
                "Id INTEGER PRIMARY KEY, " +
                "Name TEXT NOT NULL, " +
                "Category TEXT, " +
                "IsCheckedOut INTEGER NOT NULL DEFAULT 0" +
                ");";
            cmd.ExecuteNonQuery();

            // CheckoutRecords table
            cmd.CommandText =
                "CREATE TABLE IF NOT EXISTS CheckoutRecords (" +
                "Id INTEGER PRIMARY KEY, " +
                "ToolId INTEGER NOT NULL, " +
                "UserId INTEGER NOT NULL, " +
                "CheckedOut TEXT NOT NULL, " +
                "CheckedIn TEXT, " +
                "FOREIGN KEY(ToolId) REFERENCES Tools(Id), " +
                "FOREIGN KEY(UserId) REFERENCES Users(Id)" +
                ");";
            cmd.ExecuteNonQuery();
        }
    }
}
