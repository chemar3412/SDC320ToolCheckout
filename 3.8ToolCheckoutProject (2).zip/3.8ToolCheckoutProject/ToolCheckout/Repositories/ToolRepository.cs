using System;
using System.Collections.Generic;
using System.Linq;

namespace ToolCheckout.Repositories
{
    public class ToolRepository
    {
        private readonly string databaseFilePath;

        public ToolRepository(string databaseFilePath)
        {
            this.databaseFilePath = databaseFilePath;
        }

        public List<Tool> GetAll()
        {
            var list = new List<Tool>();
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Id, Name, Category, IsCheckedOut FROM Tools ORDER BY Id;";
            using var rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                int id = rdr.GetInt32(0);
                string name = rdr.GetString(1);
                string category = rdr.IsDBNull(2) ? string.Empty : rdr.GetString(2);
                bool isCheckedOut = rdr.GetInt32(3) != 0;
                var tool = new Tool(id, name, category) { IsCheckedOut = isCheckedOut };
                list.Add(tool);
            }
            return list;
        }

        public void Add(Tool tool)
        {
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "INSERT INTO Tools (Id, Name, Category, IsCheckedOut) VALUES (@id, @name, @category, @isCheckedOut);";
            var p1 = cmd.CreateParameter(); p1.ParameterName = "@id"; p1.Value = tool.Id; cmd.Parameters.Add(p1);
            var p2 = cmd.CreateParameter(); p2.ParameterName = "@name"; p2.Value = tool.Name; cmd.Parameters.Add(p2);
            var p3 = cmd.CreateParameter(); p3.ParameterName = "@category"; p3.Value = tool.Category ?? string.Empty; cmd.Parameters.Add(p3);
            var p4 = cmd.CreateParameter(); p4.ParameterName = "@isCheckedOut"; p4.Value = tool.IsCheckedOut ? 1 : 0; cmd.Parameters.Add(p4);
            cmd.ExecuteNonQuery();
        }

        public void Update(Tool tool)
        {
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE Tools SET Name = @name, Category = @category, IsCheckedOut = @isCheckedOut WHERE Id = @id;";
            var q1 = cmd.CreateParameter(); q1.ParameterName = "@name"; q1.Value = tool.Name; cmd.Parameters.Add(q1);
            var q2 = cmd.CreateParameter(); q2.ParameterName = "@category"; q2.Value = tool.Category ?? string.Empty; cmd.Parameters.Add(q2);
            var q3 = cmd.CreateParameter(); q3.ParameterName = "@isCheckedOut"; q3.Value = tool.IsCheckedOut ? 1 : 0; cmd.Parameters.Add(q3);
            var q4 = cmd.CreateParameter(); q4.ParameterName = "@id"; q4.Value = tool.Id; cmd.Parameters.Add(q4);
            cmd.ExecuteNonQuery();
        }

        public void Delete(int id)
        {
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM Tools WHERE Id = @id;";
            var d1 = cmd.CreateParameter(); d1.ParameterName = "@id"; d1.Value = id; cmd.Parameters.Add(d1);
            cmd.ExecuteNonQuery();
        }

        public void SetCheckedOut(int id, bool isCheckedOut)
        {
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE Tools SET IsCheckedOut = @isCheckedOut WHERE Id = @id;";
            var s1 = cmd.CreateParameter(); s1.ParameterName = "@isCheckedOut"; s1.Value = isCheckedOut ? 1 : 0; cmd.Parameters.Add(s1);
            var s2 = cmd.CreateParameter(); s2.ParameterName = "@id"; s2.Value = id; cmd.Parameters.Add(s2);
            cmd.ExecuteNonQuery();
        }
    }
}
