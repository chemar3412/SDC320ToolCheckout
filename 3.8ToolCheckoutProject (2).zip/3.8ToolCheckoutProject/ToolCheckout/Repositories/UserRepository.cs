using System;
using System.Collections.Generic;

namespace ToolCheckout.Repositories
{
    public class UserRepository
    {
        private readonly string databaseFilePath;

        public UserRepository(string databaseFilePath)
        {
            this.databaseFilePath = databaseFilePath;
        }

        public List<User> GetAll()
        {
            var list = new List<User>();
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Id, FullName FROM Users ORDER BY Id;";
            using var rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                int id = rdr.GetInt32(0);
                string fullName = rdr.GetString(1);
                var user = new User(id, fullName);
                list.Add(user);
            }
            return list;
        }

        public void Add(User user)
        {
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "INSERT INTO Users (Id, FullName) VALUES (@id, @fullName);";
            var p1 = cmd.CreateParameter(); p1.ParameterName = "@id"; p1.Value = user.Id; cmd.Parameters.Add(p1);
            var p2 = cmd.CreateParameter(); p2.ParameterName = "@fullName"; p2.Value = user.FullName; cmd.Parameters.Add(p2);
            cmd.ExecuteNonQuery();
        }

        public void Delete(int id)
        {
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM Users WHERE Id = @id;";
            var d1 = cmd.CreateParameter(); d1.ParameterName = "@id"; d1.Value = id; cmd.Parameters.Add(d1);
            cmd.ExecuteNonQuery();
        }
    }
}
