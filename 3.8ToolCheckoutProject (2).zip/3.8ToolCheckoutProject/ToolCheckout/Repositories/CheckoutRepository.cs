using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace ToolCheckout.Repositories
{
    public class CheckoutRepository
    {
        private readonly string databaseFilePath;

        public CheckoutRepository(string databaseFilePath)
        {
            this.databaseFilePath = databaseFilePath;
        }

        public List<CheckoutRecord> GetAll(List<Tool> tools, List<User> users)
        {
            var list = new List<CheckoutRecord>();
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Id, ToolId, UserId, CheckedOut, CheckedIn FROM CheckoutRecords ORDER BY Id;";
            using var rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                int id = rdr.GetInt32(0);
                int toolId = rdr.GetInt32(1);
                int userId = rdr.GetInt32(2);
                string checkedOutStr = rdr.GetString(3);
                string? checkedInStr = rdr.IsDBNull(4) ? null : rdr.GetString(4);

                var tool = tools.FirstOrDefault(t => t.Id == toolId);
                var user = users.FirstOrDefault(u => u.Id == userId);
                if (tool == null || user == null) continue;

                var record = new CheckoutRecord(id, tool, user);
                if (DateTime.TryParseExact(checkedOutStr, "o", CultureInfo.InvariantCulture, DateTimeStyles.None, out var co))
                    record.CheckedOut = co;
                else if (DateTime.TryParse(checkedOutStr, out var co2))
                    record.CheckedOut = co2;

                if (checkedInStr != null)
                {
                    if (DateTime.TryParseExact(checkedInStr, "o", CultureInfo.InvariantCulture, DateTimeStyles.None, out var ci))
                        record.CheckedIn = ci;
                    else if (DateTime.TryParse(checkedInStr, out var ci2))
                        record.CheckedIn = ci2;
                }

                list.Add(record);
            }
            return list;
        }

        public void Add(CheckoutRecord record)
        {
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "INSERT INTO CheckoutRecords (Id, ToolId, UserId, CheckedOut, CheckedIn) VALUES (@id, @toolId, @userId, @checkedOut, @checkedIn);";
            var p1 = cmd.CreateParameter(); p1.ParameterName = "@id"; p1.Value = record.Id; cmd.Parameters.Add(p1);
            var p2 = cmd.CreateParameter(); p2.ParameterName = "@toolId"; p2.Value = record.Tool.Id; cmd.Parameters.Add(p2);
            var p3 = cmd.CreateParameter(); p3.ParameterName = "@userId"; p3.Value = record.User.Id; cmd.Parameters.Add(p3);
            var p4 = cmd.CreateParameter(); p4.ParameterName = "@checkedOut"; p4.Value = record.CheckedOut.ToString("o"); cmd.Parameters.Add(p4);
            var p5 = cmd.CreateParameter(); p5.ParameterName = "@checkedIn"; p5.Value = (object?)record.CheckedIn?.ToString("o") ?? DBNull.Value; cmd.Parameters.Add(p5);
            cmd.ExecuteNonQuery();
        }

        public void UpdateCheckedIn(int id, DateTime? checkedIn)
        {
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE CheckoutRecords SET CheckedIn = @checkedIn WHERE Id = @id;";
            var u1 = cmd.CreateParameter(); u1.ParameterName = "@checkedIn"; u1.Value = (object?)checkedIn?.ToString("o") ?? DBNull.Value; cmd.Parameters.Add(u1);
            var u2 = cmd.CreateParameter(); u2.ParameterName = "@id"; u2.Value = id; cmd.Parameters.Add(u2);
            cmd.ExecuteNonQuery();
        }

        public void DeleteByTool(int toolId)
        {
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM CheckoutRecords WHERE ToolId = @toolId;";
            var d1 = cmd.CreateParameter(); d1.ParameterName = "@toolId"; d1.Value = toolId; cmd.Parameters.Add(d1);
            cmd.ExecuteNonQuery();
        }

        public void DeleteByUser(int userId)
        {
            using var conn = ToolCheckout.SQLiteDatabase.Connect(databaseFilePath);
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM CheckoutRecords WHERE UserId = @userId;";
            var e1 = cmd.CreateParameter(); e1.ParameterName = "@userId"; e1.Value = userId; cmd.Parameters.Add(e1);
            cmd.ExecuteNonQuery();
        }
    }
}
